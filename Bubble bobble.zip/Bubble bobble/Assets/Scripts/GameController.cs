using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameController : MonoBehaviour
{
    private int puntos;
    private int vidas;
    [SerializeField] TextMeshProUGUI textoMarcador;
    private int nivelActual;
    private int nivelMaximo;
    [SerializeField] TMP_Text textoGameOver;
    private const string MENSAJE_FIN = "Fin\n\nPuntos obtenidos: ";
    private const string MENSAJE_GAMEOVER = "Game Over";

    [SerializeField] Transform prefabFruta;

    // Start is called before the first frame update
    void Start()
    {
        textoGameOver.enabled = false;
        puntos = FindObjectOfType<GameStatus>().puntos;
        vidas = FindObjectOfType<GameStatus>().vidas;
        nivelActual = FindObjectOfType<GameStatus>().nivelActual;
        nivelMaximo = FindObjectOfType<GameStatus>().nivelMaximo;
        ActualizarMarcador();
    }

    // Update is called once per frame
    void Update()
    {
        AvanzarNivelConTabulador();
        ControlarFinDeJuego();
        // Al pulsar esc se sale al menu de bienvenida
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            TerminarPartida("");
        }
    }

    private void ControlarFinDeJuego()
    {
        if (nivelActual >= nivelMaximo)
        {            
            TerminarPartida(MENSAJE_FIN + puntos);
        }
    }

    // M�todo para avanzar nivel utilizado en las pruebas
    private void AvanzarNivelConTabulador()
    {
        if (Input.GetKeyDown(KeyCode.Tab))
            AvanzarNivel();
    }

    private void AnotarItemRecogido(int puntosObtenidos)
    {
        puntos += puntosObtenidos;
        FindObjectOfType<GameStatus>().puntos = puntos;

        ActualizarMarcador();

    }

    private void AvanzarNivel()
    {
        nivelActual++;
        if (nivelActual > nivelMaximo)
        {
            TerminarPartida(MENSAJE_FIN + puntos);
        }
        else
        {
            FindObjectOfType<GameStatus>().nivelActual = nivelActual;
            SceneManager.LoadScene("Nivel" + nivelActual);
        }
    }

    private void ActualizarMarcador()
    {
        textoMarcador.text = "Puntos: " + puntos + "\nVidas: " + vidas;
    }

    private void PerderVida()
    {
        vidas--;
        FindObjectOfType<GameStatus>().vidas = vidas;

        if (vidas <= 0)
        {
            TerminarPartida(MENSAJE_GAMEOVER);
        }
        ActualizarMarcador();
        FindObjectOfType<Player>().SendMessage("Recolocar");
    }

    private void TerminarPartida(string mensaje)
    {
        StartCoroutine(VolverAlMenuPrincipal(mensaje));
    }

    private IEnumerator VolverAlMenuPrincipal(string mensaje)
    {
        // Ralentizo el juego, espero 3 segundos y lanzo la bienvenida

        textoGameOver.color = Color.gray;
        textoGameOver.text = mensaje;
        textoGameOver.enabled = true;
        ReiniciarMarcador();
        Time.timeScale = 0.1f;
        yield return new WaitForSecondsRealtime(3);
        Time.timeScale = 1;
        SceneManager.LoadScene("Bienvenida");
    }

    private void ReiniciarMarcador()
    {
        FindObjectOfType<GameStatus>().vidas = 3;
        FindObjectOfType<GameStatus>().puntos = 0;
        FindObjectOfType<GameStatus>().nivelActual = 1;
    }
}
