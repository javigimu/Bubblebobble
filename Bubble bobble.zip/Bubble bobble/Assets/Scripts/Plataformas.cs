using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Plataformas : MonoBehaviour
{
    private PlatformEffector2D effector;

    // Start is called before the first frame update
    void Start()
    {
        effector = GetComponent<PlatformEffector2D>();
    }

    // Update is called once per frame
    void Update()
    {
        // modifico el componente PlatformEffector2D para poder bajar atravesando
        // las plataformas
        if (Input.GetAxis("Vertical") == -1)
        {
            effector.rotationalOffset = 180f;
        }

        if (Input.GetAxis("Jump") > 0 || Input.GetAxis("Vertical") < -1)
        {
            effector.rotationalOffset = 0;
        }
    }

}
