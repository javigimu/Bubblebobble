using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class Player : MonoBehaviour
{
    private float xInicial, yInicial;
    private float velocidad = 2;    
    private float velocidadSalto = 3;

    private Rigidbody2D rBody;
    SpriteRenderer spriteRenderer;
    private bool mirandoDerecha = true;
    

    private float alturaPlayer;
    private AudioSource sonidoSalto;
    [SerializeField] Transform prefabDisparo;
    private float velocidadDisparo = 2;
    private bool disparado = false;
    private float tiempoEsperaDisparo = 0.2f;

    private Animator anim;

    // Start is called before the first frame update
    void Start()
    {
        rBody = GetComponent<Rigidbody2D>();
        spriteRenderer = GetComponent<SpriteRenderer>();
        xInicial = transform.position.x;
        yInicial = transform.position.y;
        alturaPlayer = GetComponent<Collider2D>().bounds.size.y;
        //sonidoSalto = GetComponent<AudioSource>();

        anim = gameObject.GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        MoverPlayer();

        if (Input.GetButtonDown("Fire1") && !disparado)
        {
            StartCoroutine(DispararConRetardo());
            disparado = true;
        }
    }

    private IEnumerator DispararConRetardo()
    {
        Disparar();
        
        yield return new WaitForSeconds(tiempoEsperaDisparo);
        disparado = false;
    }

    private void Disparar()
    {
        anim.Play("PlayerDisparando");

        //Reproducir sonido disparo
        Quaternion rotacionDisparo = Quaternion.identity;
        if (mirandoDerecha)
            rotacionDisparo = Quaternion.identity;
        else
            rotacionDisparo = Quaternion.AngleAxis(180, Vector3.up);

        Transform disparo = Instantiate(prefabDisparo, transform.position,
            rotacionDisparo);
        disparo.gameObject.GetComponent<Rigidbody2D>().velocity =
            new Vector3(velocidadDisparo, 0, 0);
    }

    private void MoverPlayer()
    {
        float horizontal = Input.GetAxis("Horizontal");
        if (horizontal > 0)
        {
            spriteRenderer.flipX = true;
            mirandoDerecha = true;
        }
        else if (horizontal < 0)
        {
            spriteRenderer.flipX = false;
            mirandoDerecha = false;
        }

        transform.Translate(horizontal * velocidad * Time.deltaTime, 0, 0);

        float salto = Input.GetAxis("Jump");
        if (salto > 0 && ContactoSuelo.tocandoSuelo)
        {
            SaltoAvanzado();
            //Saltar();          
        }
    }

    private void SaltoAvanzado()
    {
        rBody.velocity = new Vector2(rBody.velocity.x, velocidadSalto);
    }

    private void Saltar()
    {
        RaycastHit2D hit =
            Physics2D.Raycast(transform.position, new Vector2(0, -1));

        if (hit.collider != null)
        {
            float distanciaAlSuelo = hit.distance;
            bool tocandoElSuelo = distanciaAlSuelo < alturaPlayer;
            if (tocandoElSuelo)
            {
                //EscucharSonidoSalto();
                Vector3 fuerzaSalto = new Vector3(0, velocidadSalto, 0);
                GetComponent<Rigidbody2D>().AddForce(fuerzaSalto);
            }
        }
    }

    private void EscucharSonidoSalto()
    {
        AudioSource.PlayClipAtPoint(sonidoSalto.clip, transform.position);
    }

    private void Recolocar()
    {
        transform.position = new Vector3(xInicial, yInicial, 0);
    }

}
