using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class EnemigoMorado : MonoBehaviour
{
    private float velocidad = -0.5f;
    private float velocidadBurbuja = 0.2f;
    private Animator anim;
    private bool atrapadoEnBurbuja = false;

    // Start is called before the first frame update
    void Start()
    {
        anim = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        if (!atrapadoEnBurbuja)
            MoverEnemigo();
        else
            MoverEnemigoAtrapado();
    }

    private void MoverEnemigo()
    {        
        transform.Translate(velocidad * Time.deltaTime, 0, 0);
    }

    private void OnCollisionEnter2D(Collision2D other)
    {
        if (other.gameObject.CompareTag("Paredes"))
        {
            CambiarDireccion();           
        }

        if (other.gameObject.CompareTag("Enemigo"))
        {
            other.gameObject.SendMessage("CambiarDireccion");
        }

        if (other.gameObject.CompareTag("EnemigoAtrapado"))
        {            
            Destroy(other.gameObject);
        }

        if (other.gameObject.CompareTag("Player") && atrapadoEnBurbuja)
        {
            Destroy(gameObject, 0.5f);
        }

    }

    private void CambiarDireccion()
    {
        velocidad *= -1;
    }

    private void AtraparEnBurbuja()
    {
        transform.gameObject.tag = "EnemigoAtrapado";
        anim.Play("EnemigoMoradoBurbuja");
        atrapadoEnBurbuja = true;
        GetComponent<Rigidbody2D>().gravityScale = 0;
        StartCoroutine(EsperarEnBurbuja());      
    }

    private void MoverEnemigoAtrapado()
    {
        transform.Translate(0, velocidadBurbuja * Time.deltaTime, 0);
    }

    private IEnumerator EsperarEnBurbuja()
    {
        yield return new WaitForSeconds(4);
        // si no se le mata se sale de la burbuja
        anim.Play("EnemigoMoradoBurbujaNaranja");
        StartCoroutine(EsperarEnBurbujaNaranja());
    }

    private IEnumerator EsperarEnBurbujaNaranja()
    {
        yield return new WaitForSeconds(4);
        // si no se le mata se sale de la burbuja
        anim.Play("EnemigoMoradoBurbujaRoja");
        StartCoroutine(EsperarEnBurbujaRoja());
    }
    private IEnumerator EsperarEnBurbujaRoja()
    {
        yield return new WaitForSeconds(4);
        // si no se le mata se sale de la burbuja
        anim.Play("EnemigoMoradoBurbujaRoja");
        SalirDeLaBurbuja();
    }

    private void SalirDeLaBurbuja()
    {
        transform.gameObject.tag = "Enemigo";
        anim.Play("EnemigoMorado");
        atrapadoEnBurbuja = false;
        GetComponent<Rigidbody2D>().gravityScale = 0.5f;
    }

    private void Destruir()
    {
        Destroy(gameObject);
    }
}
