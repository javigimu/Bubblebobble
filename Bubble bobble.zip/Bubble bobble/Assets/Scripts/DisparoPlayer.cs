using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DisparoPlayer : MonoBehaviour
{
    private float xInicial;
    private float distanciaDisparo = 1;
    private float velocidad = 0.5f;
    private Animator anim;

    // Start is called before the first frame update
    void Start()
    {
        xInicial = transform.position.x;
        anim = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {        
        if (transform.position.x >= xInicial + distanciaDisparo)
        {
            gameObject.GetComponent<Rigidbody2D>().velocity = 
                new Vector3(0, velocidad, 0);
            GetComponent<Collider2D>().isTrigger = false;

            Destroy(gameObject, 10f);
        }
            
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.tag == "Paredes")
        {
            GetComponent<Collider2D>().isTrigger = false;
        }

        if (other.tag == "Enemigo")
        {
            Destroy(gameObject);
            other.SendMessage("AtraparEnBurbuja");
        }

    }

    private void OnCollisionEnter2D(Collision2D other)
    {
        if (other.gameObject.CompareTag("Player"))
        {
            Destroy(gameObject);
        }
    }
}
