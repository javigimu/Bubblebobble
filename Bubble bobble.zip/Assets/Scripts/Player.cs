using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class Player : MonoBehaviour
{
    private float xInicial, yInicial;
    private float velocidad;
    private float velocidadZapatillas = 4;
    private float velocidadDisparo;
    private float tiempoEsperaDisparo;
    private float velocidadSalto = 3;
    private bool aumentarDistanciaDisparo = false;
    private bool deslizarPlayerEnPared = false;

    private Rigidbody2D rBody;
    SpriteRenderer spriteRenderer;
    private bool mirandoDerecha = true;
    [SerializeField] GameObject puntoDisparo;

    private float alturaPlayer;
    private AudioSource sonidoSalto;
    [SerializeField] Transform prefabDisparo;
   
    private bool disparado = false;   

    private Animator anim;
    bool playerPierdeVida = false;

    [SerializeField] AudioSource clipPerderVida;
    [SerializeField] AudioSource clipDispararBurbuja;

    // Start is called before the first frame update
    void Start()
    {
        velocidad = FindObjectOfType<GameStatus>().velocidadPlayer;
        velocidadDisparo = FindObjectOfType<GameStatus>().velocidadDisparo;
        tiempoEsperaDisparo = FindObjectOfType<GameStatus>().tiempoEsperaDisparo;

        rBody = GetComponent<Rigidbody2D>();
        spriteRenderer = GetComponent<SpriteRenderer>();
        xInicial = transform.position.x;
        yInicial = transform.position.y;
        alturaPlayer = GetComponent<Collider2D>().bounds.size.y;

        anim = gameObject.GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        if (!playerPierdeVida)
        {
            MoverPlayer();

            if (Input.GetButtonDown("Fire1") && !disparado)
            {
                StartCoroutine(DispararConRetardo());
                disparado = true;
            }
        }
    }

    private IEnumerator DispararConRetardo()
    {
        Disparar();
        
        yield return new WaitForSeconds(tiempoEsperaDisparo);
        disparado = false;
    }

    private void Disparar()
    {
        anim.Play("PlayerDisparando");

        AudioSource.PlayClipAtPoint(clipDispararBurbuja.clip,
            Camera.main.transform.position);

        Transform disparo = Instantiate(prefabDisparo, 
            puntoDisparo.transform.position, Quaternion.identity);

        // si ha conseguido el caramelo rosa para aumentar la velocidad le
        // mando mensaje al disparo
        if (aumentarDistanciaDisparo)
        {
            disparo.SendMessage("AumentarDistanciaDisparo");
        }

        if (mirandoDerecha)
        {
            disparo.gameObject.GetComponent<Rigidbody2D>().velocity =
                new Vector3(velocidadDisparo, 0, 0);
        }
        else
        {
            disparo.gameObject.GetComponent<Rigidbody2D>().velocity =
                new Vector3(-velocidadDisparo, 0, 0);
        }
    }

    private void MoverPlayer()
    {
        float horizontal = Input.GetAxis("Horizontal");
        if (horizontal > 0)
        {
            spriteRenderer.flipX = true;
            mirandoDerecha = true;
        }
        else if (horizontal < 0)
        {
            spriteRenderer.flipX = false;
            mirandoDerecha = false;
        }

        if (!deslizarPlayerEnPared || 
            (deslizarPlayerEnPared && ContactoSuelo.tocandoSuelo))
        {            
            transform.Translate(horizontal * velocidad * Time.deltaTime, 0, 0);
        }            

        float salto = Input.GetAxis("Jump");
        if (salto > 0 && ContactoSuelo.tocandoSuelo)
        {
            SaltoAvanzado();
            //Saltar();          
        }
    }

    private void SaltoAvanzado()
    {
        rBody.velocity = new Vector2(rBody.velocity.x, velocidadSalto);
    }

    private void Saltar()
    {
        RaycastHit2D hit =
            Physics2D.Raycast(transform.position, new Vector2(0, -1));

        if (hit.collider != null)
        {
            float distanciaAlSuelo = hit.distance;
            bool tocandoElSuelo = distanciaAlSuelo < alturaPlayer;
            if (tocandoElSuelo)
            {
                //EscucharSonidoSalto();
                Vector3 fuerzaSalto = new Vector3(0, velocidadSalto, 0);
                GetComponent<Rigidbody2D>().AddForce(fuerzaSalto);
            }
        }
    }

    private void EscucharSonidoSalto()
    {
        AudioSource.PlayClipAtPoint(sonidoSalto.clip, transform.position);
    }

    private IEnumerator Recolocar()
    {
        yield return new WaitForSeconds(3);        
        anim.Play("Player");
        transform.position = new Vector3(xInicial, yInicial, 0);
        playerPierdeVida = false;
        FindObjectOfType<GameController>().SendMessage("RecolocarEnemigos");
    }

    private void PerderVida()
    {
        if (!playerPierdeVida)
        {
            AudioSource.PlayClipAtPoint(clipPerderVida.clip,
                Camera.main.transform.position);
            playerPierdeVida = true;
            anim.Play("MuertePlayer");
            FindObjectOfType<GameController>().SendMessage("PerderVida");
            ResetearAtributos();
        }
    }

    private void AumentarVelocidad()
    {
        velocidad = velocidadZapatillas;
        FindObjectOfType<GameStatus>().velocidadPlayer = velocidad;
    }

    private void ReducirTiempoEsperaDisparo()
    {
        tiempoEsperaDisparo = 0;
        FindObjectOfType<GameStatus>().tiempoEsperaDisparo = 0;
    }

    private void AumentarVelocidadDisparo()
    {
        velocidadDisparo = 4;
        FindObjectOfType<GameStatus>().velocidadDisparo = 4;
    }

    private void AumentarDistanciaDisparo()
    {
        aumentarDistanciaDisparo = true;
    }

    private void ResetearAtributos()
    {
        velocidad = FindObjectOfType<GameStatus>().velocidadPlayerInicial;
        velocidadDisparo = FindObjectOfType<GameStatus>().velocidadDisparoInicial;
        tiempoEsperaDisparo = FindObjectOfType<GameStatus>().tiempoEsperaDisparoInicial;
        FindObjectOfType<GameStatus>().velocidadPlayer = velocidad;
        FindObjectOfType<GameStatus>().tiempoEsperaDisparo = tiempoEsperaDisparo;
        FindObjectOfType<GameStatus>().velocidadDisparo = velocidadDisparo;

        // atributos del disparo
        aumentarDistanciaDisparo = false;
        FindObjectOfType<GameStatus>().distanciaDisparo = 
            FindObjectOfType<GameStatus>().distanciaDisparoInicial;
    }
    
    private void Reposicionar(Vector3 posicion)
    {
        transform.position = posicion;
    }

    private void SepararDePared()
    {
        deslizarPlayerEnPared = true;
    }

    public void DejarDeSepararDePared()
    {
        deslizarPlayerEnPared = false;
    }
}
