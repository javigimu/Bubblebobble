using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
using Random = UnityEngine.Random;

public class GameController : MonoBehaviour
{
    private int puntos;
    private int puntosRecord;
    private int vidas;
    private int nivelActual;
    private int nivelMaximo;
    private int tiempoEsperaNuevoRegalo = 5;

    [SerializeField] TMP_Text textoGameOver;
    [SerializeField] TMP_Text textoPuntosJugador;
    [SerializeField] TMP_Text textoPuntosRecord;
   
    private const string MENSAJE_FIN = "Fin\n\nPuntos obtenidos: ";
    private const string MENSAJE_GAMEOVER = "Game Over";

    [SerializeField] Transform prefabFruta;
    [SerializeField] Transform prefabCarameloRosa;
    [SerializeField] Transform prefabCarameloAzul;
    [SerializeField] Transform prefabCarameloAmarillo;
    [SerializeField] Transform prefabZapatillas;

    private bool crearFrutasFinNivel = true;

    // Start is called before the first frame update
    void Start()
    {
        puntosRecord = FindObjectOfType<GameStatus>().puntosRecord;
        textoGameOver.enabled = false;
        puntos = FindObjectOfType<GameStatus>().puntos;
        vidas = FindObjectOfType<GameStatus>().vidas;
        nivelActual = FindObjectOfType<GameStatus>().nivelActual;
        nivelMaximo = FindObjectOfType<GameStatus>().nivelMaximo;
        ActualizarMarcador();

        MostrarCorazones();
        StartCoroutine(CrearCarameloOZapatillas());
    }

    // Update is called once per frame
    void Update()
    {
        if (FindObjectsOfType<EnemigoMorado>().Length <= 0)
        {
            StartCoroutine(EsperarYAvanzarNivel());            
        }

        AvanzarNivelConTabulador();
        ControlarFinDeJuego();
        // Al pulsar esc se sale al menu de bienvenida
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            TerminarPartida("");
        }
    }

    public IEnumerator CrearCarameloOZapatillas()
    {
        yield return new WaitForSeconds(tiempoEsperaNuevoRegalo);
        MostrarCarameloOZapatilla();
        StartCoroutine(CrearCarameloOZapatillas());
    }

    private IEnumerator EsperarYAvanzarNivel()
    {
        if (crearFrutasFinNivel)
        {
            FindObjectOfType<AudioController>().SendMessage("EscucharSonidoAvanzarNivel");
            MostrarFruta(5);
            crearFrutasFinNivel = false;
        }
        yield return new WaitForSeconds(5);
        AvanzarNivel();
    }

    private void ControlarFinDeJuego()
    {
        if (nivelActual > nivelMaximo)
        {
            TerminarPartida(MENSAJE_FIN + puntos);
        }
    }

    // M�todo para avanzar nivel utilizado en las pruebas
    private void AvanzarNivelConTabulador()
    {
        if (Input.GetKeyDown(KeyCode.Tab))
            AvanzarNivel();
    }

    public void SumarPuntos(int puntosObtenidos)
    {
        puntos += puntosObtenidos;
        if (puntos > puntosRecord)
            FindObjectOfType<GameStatus>().puntosRecord = puntos;
        FindObjectOfType<GameStatus>().puntos = puntos;
        ActualizarMarcador();
    }

    private void MostrarFrutaYSumarPuntos(int puntos)
    {
        MostrarFruta(1);
        SumarPuntos(puntos);
    }

    private void InstanciarPrefab(Transform prefab)
    {
        // horizontal -2 a 2 y vertical -1 a 1
        float posX = Random.Range(-2f, 2f);
        float posY = Random.Range(-1f, 1f);
        Vector3 posicion = new Vector3(posX, posY, 0);
        Instantiate(prefab, posicion, Quaternion.identity);
    }

    private void MostrarFruta(int numeroDeFrutas)
    {
        for (int i = 0; i < numeroDeFrutas; i++)
        {
            InstanciarPrefab(prefabFruta);
        }
    }

    private void MostrarCarameloOZapatilla()
    {
        System.Random random = new System.Random();
        int item = random.Next(1, 5);
        switch (item)
        {
            case 1: InstanciarPrefab(prefabCarameloAzul); break;
            case 2: InstanciarPrefab(prefabCarameloRosa); break;
            case 3: InstanciarPrefab(prefabCarameloAmarillo); break;
            case 4: InstanciarPrefab(prefabZapatillas); break;
        }        
    }

    private void AvanzarNivel()
    {
        nivelActual++;
        if (nivelActual > nivelMaximo)
        {
            TerminarPartida(MENSAJE_FIN + puntos);
        }
        else
        {
            FindObjectOfType<GameStatus>().nivelActual = nivelActual;
            SceneManager.LoadScene("Nivel" + nivelActual);
        }
    }

    private void ActualizarMarcador()
    {
        textoPuntosJugador.text = puntos + "";
        if (puntos > puntosRecord)
            textoPuntosRecord.text = puntos + "";
        else
            textoPuntosRecord.text = puntosRecord + "";
    }

    private void PerderVida()
    {
        vidas--;
        OcultarCorazon(vidas);
        FindObjectOfType<GameStatus>().vidas = vidas;        

        if (vidas <= 0)
        {
            TerminarPartida(MENSAJE_GAMEOVER);
        }
        ActualizarMarcador();
        FindObjectOfType<Player>().SendMessage("Recolocar");        
    }

    private void OcultarCorazon(int vidas)
    {
        Corazon[] corazones = FindObjectsOfType<Corazon>();
        corazones[vidas].GetComponent<SpriteRenderer>().enabled = false;
    }

    private void MostrarCorazones()
    {
        if (vidas == 2)
            OcultarCorazon(2);

        if (vidas == 1)
            OcultarCorazon(1);

        if (vidas == 0)
            OcultarCorazon(0);
    }

    private void RecolocarEnemigos()
    {
        foreach (EnemigoMorado em in FindObjectsOfType<EnemigoMorado>())
        {
            if (em.tag == "Enemigo")
                em.SendMessage("Recolocar");
        }

        foreach (EnemigoFantasma em in FindObjectsOfType<EnemigoFantasma>())
        {
            if (em.tag == "EnemigoFantasma")
                em.SendMessage("Recolocar");
        }
    }

    private void TerminarPartida(string mensaje)
    {        
        StartCoroutine(VolverAlMenuPrincipal(mensaje));
    }

    private IEnumerator VolverAlMenuPrincipal(string mensaje)
    {
        // Ralentizo el juego, espero 5 segundos y lanzo la bienvenida
        FindObjectOfType<GameStatus>().SendMessage("SalvarPuntosRecord");

        textoGameOver.color = Color.white;
        textoGameOver.text = mensaje;
        textoGameOver.enabled = true;
        ReiniciarMarcador();
        Time.timeScale = 0.1f;
        yield return new WaitForSecondsRealtime(5);
        Time.timeScale = 1;
        SceneManager.LoadScene("Bienvenida");
    }

    private void ReiniciarMarcador()
    {
        FindObjectOfType<GameStatus>().vidas = 3;
        FindObjectOfType<GameStatus>().puntos = 0;
        FindObjectOfType<GameStatus>().nivelActual = 1;
        FindObjectOfType<Player>().SendMessage("ResetearAtributos");
    }
  
}
