using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;

public class Fruta : MonoBehaviour
{
    private Animator anim;
    private float tiempoDeVida = 5;
    private int puntos;
    private AudioSource clipRecogerFruta;
    private float velocidad = -1f;
    private bool tocandoPlataforma = false;

    // Start is called before the first frame update
    void Start()
    {
        anim = GetComponent<Animator>();
        clipRecogerFruta = GetComponent<AudioSource>();
        SeleccionarAnimacionAleatoria();        
        Destroy(gameObject, tiempoDeVida);        
    }
   
    // Update is called once per frame
    void Update()
    {
        if (!tocandoPlataforma)
            MoverHaciaAbajo();
    }

    private void MoverHaciaAbajo()
    {
        transform.Translate(0, velocidad * Time.deltaTime, 0);
    }

    private void PararMovimiento()
    {
        transform.Translate(0, 0, 0);
    }

    // seleccionar animacion aleatoria entre las 7 disponibles
    private void SeleccionarAnimacionAleatoria()
    {
        int animacion = Random.Range(1, 7);
        switch (animacion)
        {
            case 1:
                anim.Play("Fruta");
                puntos = 500;
                break;
            case 2:
                anim.Play("Manzana");
                puntos = 700;
                break;
            case 3:
                anim.Play("Cerezas");
                puntos = 1000;
                break;
            case 4:
                anim.Play("Kiwi");
                puntos = 300;
                break;
            case 5:
                anim.Play("Melon");
                puntos = 500;
                break;
            case 6:
                anim.Play("Naranja");
                puntos = 800;
                break;
            case 7:
                anim.Play("Pinya");
                puntos = 900;
                break;
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.tag == "Player")
        {
            AudioSource.PlayClipAtPoint(clipRecogerFruta.clip,
                Camera.main.transform.position);

            // Desactivo la fruta desde su SpriteRender
            // activo la animaci�n y destruyo todo
            FindObjectOfType<GameController>().SendMessage("SumarPuntos", puntos);
            GetComponent<SpriteRenderer>().enabled = false;
            gameObject.transform.GetChild(0).gameObject.SetActive(true);
            Destroy(gameObject, 0.5f);
        }

        if (other.tag == "Plataforma" || other.tag == "Suelo")
        {
            tocandoPlataforma = true;
            PararMovimiento();
        }
    }

    private void Reposicionar(Vector3 posicion)
    {
        transform.position = posicion;
    }
}
