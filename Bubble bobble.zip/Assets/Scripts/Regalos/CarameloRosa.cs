using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CarameloRosa : MonoBehaviour
{
    private float tiempoDeVida = 5;
    private float velocidad = -1f;
    private bool tocandoPlataforma = false;

    // Incrementa la distancia de la burbuja
    // Start is called before the first frame update
    void Start()
    {
        Destroy(gameObject, tiempoDeVida);
    }

    // Update is called once per frame
    void Update()
    {
        if (!tocandoPlataforma)
            MoverHaciaAbajo();
    }

    private void MoverHaciaAbajo()
    {
        transform.Translate(0, velocidad * Time.deltaTime, 0);
    }

    private void PararMovimiento()
    {
        transform.Translate(0, 0, 0);
    }
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.tag == "Player")
        {
            FindObjectOfType<AudioController>().SendMessage("EscucharSonidoRecogerCaramelo");
            FindObjectOfType<Player>().SendMessage("AumentarDistanciaDisparo");
            Destroy(gameObject);
        }

        if (other.tag == "Plataforma" || other.tag == "Suelo")
        {
            tocandoPlataforma = true;
            PararMovimiento();
        }
    }

    private void Reposicionar(Vector3 posicion)
    {
        transform.position = posicion;
    }
}
