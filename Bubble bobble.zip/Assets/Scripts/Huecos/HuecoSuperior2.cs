using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HuecoSuperior2 : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.tag == "DisparoPlayer")
        {
            Destroy(other.gameObject);
        }

        if (other.tag == "EnemigoAtrapado")
        {
            other.transform.Translate(new Vector2(0.1f, -0.01f));
        }
    }
}
