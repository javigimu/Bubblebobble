using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DisparoPlayer : MonoBehaviour
{
    private float xInicial;
    private float distanciaDisparo;
    private float velocidad = 0.5f;
    private Animator anim;

    // Start is called before the first frame update
    void Start()
    {
        xInicial = transform.position.x;
        anim = GetComponent<Animator>();
        distanciaDisparo = FindObjectOfType<GameStatus>().distanciaDisparo;
        Destroy(gameObject, 10f);
    }

    // Update is called once per frame
    void Update()
    {        
        if (transform.position.x >= xInicial + distanciaDisparo ||
            transform.position.x <= xInicial - distanciaDisparo)
        {
            gameObject.GetComponent<Rigidbody2D>().velocity = 
                new Vector3(0, velocidad, 0);
            GetComponent<Collider2D>().isTrigger = false;            
        }
            
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.tag == "Paredes" || other.tag == "EnemigoAtrapado")
        {
            GetComponent<Collider2D>().isTrigger = false;
        }

        if (other.tag == "DisparoPlayer")
        {
            GetComponent<Collider2D>().isTrigger = true;
        }

        if (other.tag == "Enemigo" || other.tag == "EnemigoFantasma")
        {
            Destroy(gameObject);
            other.SendMessage("AtraparEnBurbuja");
        }        
    }

    private void OnCollisionEnter2D(Collision2D other)
    {
        if (other.gameObject.CompareTag("Player"))
        {
            FindObjectOfType<AudioController>().SendMessage("EscucharExplosionBurbuja");

            GetComponent<SpriteRenderer>().enabled = false;
            gameObject.transform.GetChild(0).gameObject.SetActive(true);
            Destroy(gameObject, 0.5f);
        }
    }

    private void AumentarDistanciaDisparo()
    {
        distanciaDisparo = 2;
        FindObjectOfType<GameStatus>().distanciaDisparo = distanciaDisparo;
    }

    private void ResetearAtributos()
    {
        distanciaDisparo = FindObjectOfType<GameStatus>().distanciaDisparoInicial;
        FindObjectOfType<GameStatus>().distanciaDisparo = distanciaDisparo;
    }

}
