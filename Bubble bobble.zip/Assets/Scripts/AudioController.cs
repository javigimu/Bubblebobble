using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AudioController : MonoBehaviour
{
    [SerializeField] AudioSource musicaJuego;
    [SerializeField] AudioSource sonidoAvanzarNivel;
    [SerializeField] AudioSource sonidoExplosionBurbuja;
    [SerializeField] AudioSource sonidoRecogerCaramelo;

    // Start is called before the first frame update
    void Start()
    {
        musicaJuego.Play();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void EscucharSonidoAvanzarNivel()
    {
        sonidoAvanzarNivel.Play();
    }

    private void EscucharExplosionBurbuja()
    {
        sonidoExplosionBurbuja.Play();
    }

    private void EscucharSonidoRecogerCaramelo()
    {
        sonidoRecogerCaramelo.Play();
    }
}
