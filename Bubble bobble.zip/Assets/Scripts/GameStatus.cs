using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

public class GameStatus : MonoBehaviour
{
    public int puntos = 0;
    public int puntosRecord;
    public int vidas = 3;
    public int nivelActual = 1;
    public int nivelMaximo = 3;
    public float velocidadPlayer = 2;
    public float velocidadDisparo = 2;
    public float tiempoEsperaDisparo = 0.5f;
    public float distanciaDisparo = 1;
    public float velocidadPlayerInicial = 2;
    public float velocidadDisparoInicial = 2;
    public float tiempoEsperaDisparoInicial = 0.5f;
    public float distanciaDisparoInicial = 1;

    // Awake is called before Start
    private void Awake()
    {
        int gameStatusCount = FindObjectsOfType<GameStatus>().Length;        

        if (gameStatusCount > 1)
        {
            Destroy(gameObject);
        }
        else
        {
            puntosRecord = CargarPuntosRecord();
            DontDestroyOnLoad(gameObject);
        }
    }

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }

    private void SalvarPuntosRecord()
    {
        File.WriteAllText("record.txt", puntosRecord + "");
    }

    private int CargarPuntosRecord()
    {
        if (File.Exists("record.txt"))
            return Convert.ToInt32(File.ReadAllText("record.txt"));
        else
            return 0;
    }
}
