using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DisparoEnemigoFantasma : MonoBehaviour
{
    private Animator anim;

    // Start is called before the first frame update
    void Start()
    {
        anim = GetComponent<Animator>();
        Destroy(gameObject, 10f);
    }

    // Update is called once per frame
    void Update()
    {

    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.tag == "Paredes" || other.tag == "Plataforma")
        {
            Destroy(gameObject);
        }

        if (other.tag == "Player")
        {
            Destroy(gameObject);
            other.SendMessage("PerderVida");
        }

    }
}
