using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Corazon : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OcultarCorazon()
    {
        GetComponent<SpriteRenderer>().enabled = false;
    }

    private void MostrarCorazon()
    {
        GetComponent<SpriteRenderer>().enabled = true;
    }
}
