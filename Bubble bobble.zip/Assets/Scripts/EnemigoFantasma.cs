using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemigoFantasma : MonoBehaviour
{
    private Animator anim;

    private float velocidad = -0.5f;
    private float velocidadEnfadado = -1.5f;
    private float velocidadBurbuja = 0.1f;
    private bool atrapadoEnBurbuja = false;
    private float xInicial;
    private float yInicial;
    public bool mirandoIzquierda = true;
    private int puntos = 2000;

    private float velocidadDisparo = 1.5f;
    private float velocidadDisparoEnfadado = 2.5f;

    [SerializeField] GameObject puntoDisparo;
    [SerializeField] Transform prefabDisparo;
    [SerializeField] AudioSource clipDispararFireball;

    private bool juegoIniciado = false;

    // Start is called before the first frame update
    void Start()
    {
        xInicial = transform.position.x;
        yInicial = transform.position.y;
        anim = GetComponent<Animator>();

        StartCoroutine(EsperarInicio());        
    }

    // Update is called once per frame
    void Update()
    {
        if (juegoIniciado)
        {
            if (!atrapadoEnBurbuja)
                MoverEnemigo();
            else
                MoverEnemigoAtrapado();
        }
    }

    private IEnumerator EsperarInicio()
    {
        yield return new WaitForSeconds(3);
        juegoIniciado = true;
        StartCoroutine(Disparar());
    }

    private void MoverEnemigo()
    {
        transform.Translate(velocidad * Time.deltaTime, 0, 0);
    }

    private void MoverEnemigoAtrapado()
    {
        float velocidadX = Random.Range(-0.01f, 0.01f);
        transform.Translate(velocidadX * Time.deltaTime,
            velocidadBurbuja * Time.deltaTime, 0);
    }

    private IEnumerator Disparar()
    {
        float pausaDisparo = Random.Range(2f, 5f);
        yield return new WaitForSeconds(pausaDisparo);

        if (!atrapadoEnBurbuja)
        {
            AudioSource.PlayClipAtPoint(clipDispararFireball.clip,
                Camera.main.transform.position);

            Transform disparo = Instantiate(prefabDisparo,
                transform.position, Quaternion.identity);

            if (mirandoIzquierda)
            {
                disparo.gameObject.GetComponent<Rigidbody2D>().velocity =
                    new Vector3(-velocidadDisparo, 0, 0);
            }
            else
            {
                disparo.gameObject.GetComponent<Rigidbody2D>().velocity =
                    new Vector3(velocidadDisparo, 0, 0);
            }
        }        
        StartCoroutine(Disparar());
    }   

    private void OnCollisionEnter2D(Collision2D other)
    {
        if (other.gameObject.CompareTag("Paredes"))
        {
            // lo separo un poco de la pared y cambio de direcci�n
            if (mirandoIzquierda)
            {
                transform.position = new Vector3(transform.position.x - 0.1f,
                    transform.position.y, 0);
            }
            else
            {
                transform.position = new Vector3(transform.position.x + 0.1f,
                    transform.position.y, 0);
            }
            CambiarDireccion();
        }

        if (other.gameObject.CompareTag("Enemigo") 
            || other.gameObject.CompareTag("EnemigoFantasma"))
        {
            other.gameObject.SendMessage("CambiarDireccion");
        }

        if (other.gameObject.CompareTag("Player"))
        {
            if (atrapadoEnBurbuja)
            {
                FindObjectOfType<AudioController>().SendMessage(
                    "EscucharExplosionBurbuja");

                GetComponent<SpriteRenderer>().enabled = false;
                gameObject.transform.GetChild(0).gameObject.SetActive(true);
                Destroy(gameObject, 0.5f);
                FindObjectOfType<GameController>().SendMessage(
                    "MostrarFrutaYSumarPuntos", puntos);
            }
            else
            {
                FindObjectOfType<Player>().SendMessage("PerderVida");
            }
        }
    }

    private void CambiarDireccion()
    {
        velocidad *= -1;
        velocidadEnfadado *= -1;
        if (mirandoIzquierda)
        {
            GetComponent<SpriteRenderer>().flipX = true;
            mirandoIzquierda = false;
        }
        else
        {
            GetComponent<SpriteRenderer>().flipX = false;
            mirandoIzquierda = true;
        }
    }

    private void AtraparEnBurbuja()
    {
        transform.gameObject.tag = "EnemigoAtrapado";
        anim.Play("EnemigoFantasmaBurbuja");
        atrapadoEnBurbuja = true;
        GetComponent<Rigidbody2D>().gravityScale = 0;
        StartCoroutine(EsperarEnBurbuja());
    }

    private IEnumerator EsperarEnBurbuja()
    {
        yield return new WaitForSeconds(4);
        // si no se le mata se sale de la burbuja
        anim.Play("EnemigoFantasmaBurbujaNaranja");
        StartCoroutine(EsperarEnBurbujaNaranja());
    }

    private IEnumerator EsperarEnBurbujaNaranja()
    {
        yield return new WaitForSeconds(2);
        // si no se le mata se sale de la burbuja
        anim.Play("EnemigoFantasmaBurbujaRoja");
        StartCoroutine(EsperarEnBurbujaRoja());
    }
    private IEnumerator EsperarEnBurbujaRoja()
    {
        yield return new WaitForSeconds(2);
        // si no se le mata se sale de la burbuja
        anim.Play("EnemigoFantasmaBurbujaRoja");
        SalirDeLaBurbuja();
    }

    private void SalirDeLaBurbuja()
    {
        transform.gameObject.tag = "EnemigoFantasma";
        anim.Play("EnemigoFantasma");
        atrapadoEnBurbuja = false;
        velocidadDisparo = velocidadDisparoEnfadado;
        GetComponent<Rigidbody2D>().gravityScale = 0.5f;

        // tras salir de la burbuja se enfada, cambio de color y velocidad
        velocidad = velocidadEnfadado;
        anim.Play("EnemigoFantasmaEnfadado");
    }

    private void Destruir()
    {
        Destroy(gameObject);
    }

    private void Recolocar()
    {
        if (!atrapadoEnBurbuja)
            transform.position = new Vector3(xInicial, yInicial, 0);
    }

    private void Reposicionar(Vector3 posicion)
    {
        transform.position = posicion;
    }
}
